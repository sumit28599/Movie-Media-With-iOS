//
//  Constant.swift
//  MovieMedia
//
//  Created by iPHTech 29 on 02/05/23.
//

import Foundation

let controllerIdentifier = "MoviesDetailsViewController"


